<?php
$cn=mysqli_connect("localhost","root","","poll") or die("Could not Connect My Sql");

?>
