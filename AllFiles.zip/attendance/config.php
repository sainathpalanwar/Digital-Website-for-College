
<?php
$connect=mysqli_connect("localhost","root","","poll");
if(!$connect)
{
	echo "Error".mysql_error();
	}
	
	




?>