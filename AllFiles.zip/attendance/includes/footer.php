       <div class="templatemo-footer">
            <div class="container">
                <div class="row" style="margin-top:20px;">
                        <div class="col-md-3">
                        </div>
                        <div class="col-md-7 footer_txt" >
                                <span>  
                        <div class="footer_bottom_content">
                    
                            <p>Copyright&copy;<?php echo date('Y'); ?> mgm nanded</p>
                       
                        
                        </div></span>
            
                        </div>
                 </div>
            </div>
        </div>


        <script src="js/jquery.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js"  type="text/javascript"></script>
        <script src="js/templatemo_script.js"  type="text/javascript"></script>
        <script src="js/myscript.js"  type="text/javascript"></script>


    </body>
</html>


