<?php
$conn=mysqli_connect("localhost","root","","feedback")or die(mysqli_error());
?>