<?php 
include('connection.php');
session_start();
 ?>
<html>
	<head>
		<title>Notice Board</title>
		<link rel="stylesheet" href="css/bootstrap.css"/>
		<script src="js/jquery_library.js"></script>
<script src="js/bootstrap.min.js"></script>
	</head>
	<body>
			<nav class="navbar navbar-default navbar-fixed-top" style="background:#000">
  <div class="container">
  
  <ul class="nav navbar-nav navbar-left">
    <li><a href="index.php"><strong>Notice Board</strong></a></li>
      
	  
	</ul>


<ul class="nav navbar-nav navbar-right">
      <li><a href="index.php?option=New_user"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="index.php?option=login"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>



</div>
</nav>	

<div class="container-fluid">
	


 
  <div  >
    <div >
      
      

    </div>
    ...
  </div>


</div>

</div>


<div class="container">
	<div class="row">
	
		<div class="col-sm-8">
		<?php 
		@$opt=$_GET['option'];
		
		if($opt!="")
		{
			
			 if($opt=="New_user")
			{
			include('registration.php');
			}
			
			
			else if($opt=="login")
			{
			include('login.php');
			}
		}
		else
		{
		echo "<h2></h2>
		Welcome 
		Welcome user Welcome user Welcome user Welcome user Welcome user Welcome user user 
				Welcome 
		Welcome user Welcome user Welcome user Welcome user Welcome user Welcome user user";
		}
		?>
		
		
		
		
		</div>
	


<br/>
<br/>
<br/>
<br/>



	</body>
</html>