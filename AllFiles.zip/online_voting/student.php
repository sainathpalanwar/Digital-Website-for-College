<?php
require('connection.php');

session_start();

if(empty($_SESSION['member_id'])){
 header("location:access-denied.php");
}
?>
<html><head>
<link href="css/user_styles.css" rel="stylesheet" type="text/css" />
</head>
<body background="Vote.jpg">

<center><b><font color = "brown" size="6">Simple PHP Polling System</font></b></center><br><br>
<div id="page">
<div id="header">
<h1>STUDENT HOME </h1>
<a href="student.php"><font size="6">Home</font></a> | <a href="vote.php"><font size="6">Current Polls</font></a> | <a href="manage-profile.php"><font size="6">Manage My Profile</font></a> | <a href="logout.php"><font size="6">Logout</font></a>
</div>
<div id="container">
<p> Click a link above to do some stuff.</p>
</div>
<div id="footer">
 <div class="bottom_addr">MGM College Of Engineering,Nanded.</div>
</div>
</div>
</body></html>