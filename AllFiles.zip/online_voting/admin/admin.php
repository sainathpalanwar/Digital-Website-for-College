<?php
session_start();
require('../connection.php');

if(empty($_SESSION['admin_id'])){
 header("location:access-denied.php");
}
?>
<html><head>
<link href="css/admin_styles.css" rel="stylesheet" type="text/css" />
</head>
<body background="Vote.jpg">
    
<center><b><font color = "brown" size="6">Simple PHP Polling System</font></b></center><br><br>
<div id="page">
<div id="header">
<h1>ADMINISTRATION CONTROL PANEL </h1>
<a href="admin.php"><font size="6">Home</font></a> | <a href="manage-admins.php"><font size="6">Manage Administrators</font></a> | <a href="positions.php"><font size="6">Manage Positions</font></a> | <a href="candidates.php"><font size="6">Manage Candidates</font></a> | <a href="refresh.php"><font size="6">Poll Results</font></a> | <a href="logout.php"><font size="6">Logout</font></a>
</div>
<p align="center">&nbsp;</p>
<div id="container">

<p>Click a link above to perform an administrative operation.</p>


</div>
<div id="footer">
 <div class="bottom_addr">MGM College Of Engineering,Nanded.</div>
</div>
</div>
</body></html>