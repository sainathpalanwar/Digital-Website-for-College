<?php
session_start();
require('../connection.php');

if(empty($_SESSION['admin_id'])){
 header("location:access-denied.php");
} 

$result=mysqli_query($conn,"SELECT * FROM tbCandidates")
or die("There are no records to display ... \n" . mysql_error()); 
if (mysqli_num_rows($result)<1){
    $result = null;
}
?>
<?php

$positions_retrieved=mysqli_query($conn,"SELECT * FROM tbPositions")
or die("There are no records to display ... \n" . mysql_error()); 

?>
<?php

if (isset($_POST['Submit']))
{

$newCandidateName = addslashes( $_POST['name'] ); 
$newCandidatePosition = addslashes( $_POST['position'] );

$sql = mysqli_query($conn,"INSERT INTO tbCandidates(candidate_name,candidate_position) VALUES ('$newCandidateName','$newCandidatePosition')" )
        or die("Could not insert candidate at the moment". mysql_error() );


 header("Location: candidates.php");
}
?>
<?php

 if (isset($_GET['id']))
 {

 $id = $_GET['id'];
 

 $result = mysqli_query($conn,"DELETE FROM tbCandidates WHERE candidate_id='$id'")
 or die("The candidate does not exist ... \n"); 

 header("Location: candidates.php");
 }
 else
 
?>

<html>
<head>

<title>Administration Control Panel:Candidates</title>
<link href="css/admin_styles.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" src="js/admin.js">
</script>
</head>
<body background="Vote.jpg">
<center><b><font color = "brown" size="6">Simple PHP Polling System</font></b></center><br><br>
<div id="page">
<div id="header">
  <h1>MANAGE CANDIDATES</h1>
  <a href="admin.php"><font size="6">Home</font></a> | <a href="manage-admins.php"><font size="6">Manage Administrators</font></a> | <a href="positions.php"><font size="6">Manage Positions</font></a> | <a href="candidates.php"><font size="6">Manage Candidates</font></a> | <a href="refresh.php"><font size="6">Poll Results</font></a> | <a href="logout.php"><font size="6">Logout</font></a>

</div>
<div id="container">
<table width="380" align="center">
<CAPTION><h3>ADD NEW CANDIDATE</h3></CAPTION>
<form name="fmCandidates" id="fmCandidates" action="candidates.php" method="post" onsubmit="return candidateValidate(this)">
<tr>
    <td>Candidate Name</td>
    <td><input type="text" name="name" /></td>
</tr>
<tr>
    <td>Candidate Position</td>
   <?php echo $positions; ?>
    <td><SELECT NAME="position" id="position">select
    <OPTION VALUE="select">select
    <?php

    while ($row=mysqli_fetch_array($positions_retrieved)){
    echo "<OPTION VALUE=$row[position_name]>$row[position_name]";
   
    }
    ?>
    </SELECT>
    </td>
</tr>
<tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="Submit" value="Add" /></td>
</tr>
</table>
<hr>
<table border="0" width="620" align="center">
<CAPTION><h3>AVAILABLE CANDIDATES</h3></CAPTION>
<tr>
<th>Candidate ID</th>
<th>Candidate Name</th>
<th>Candidate Position</th>
</tr>

<?php

while ($row=mysqli_fetch_array($result)){
echo "<tr>";
echo "<td>" . $row['candidate_id']."</td>";
echo "<td>" . $row['candidate_name']."</td>";
echo "<td>" . $row['candidate_position']."</td>";
echo '<td><a href="candidates.php?id=' . $row['candidate_id'] . '">Delete Candidate</a></td>';
echo "</tr>";
}
mysqli_free_result($result);
mysqli_close($link);
?>
</table>
<hr>
</div>
<div id="footer"> 
  <div class="bottom_addr">MGM College Of Engineering,Nanded.</div>
</div>
</div>
</body>
</html>