<?php
error_reporting(1);
$conn=mysqli_connect('localhost', 'root', '','poll') or die(mysql_error());


?>
