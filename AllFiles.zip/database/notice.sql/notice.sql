--
-- Database: `notice`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `user`, `pass`) VALUES
(1, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `notice_id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `Description` text NOT NULL,
  `Date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`notice_id`, `user`, `subject`, `Description`, `Date`) VALUES
(8, 'palanwars@gmail.com', 'External', 'project external is on 12/may/2018', '2018-05-10 09:24:34'),
(9, 'sumashril100@gmail.com', 'df', 'dgfsdg', '2018-05-10 10:07:15');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` char(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pass` varchar(40) NOT NULL,
  `mobile` bigint(11) NOT NULL,
  `gender` varchar(40) NOT NULL,
  `hobbies` varchar(40) NOT NULL,
  `image` varchar(50) NOT NULL,
  `dob` datetime NOT NULL,
  `regid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `pass`, `mobile`, `gender`, `hobbies`, `image`, `dob`, `regid`) VALUES
(12, 'sainath', 'palanwars@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 8381099576, 'm', 'reading', 'download.jpg', '1995-12-29 00:00:00', 2147483647),
(13, 'sumashri', 'sumashril100@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 9664512988, 'f', 'singin', 'Koala.jpg', '1996-11-07 00:00:00', 2147483647),
(14, 'avinash', 'kanjalkaravi@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 8857014324, 'm', 'singin', 'Lighthouse.jpg', '1995-08-15 00:00:00', 2147483647),
(15, 'shreyass', 'bhoyar@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 9860388909, 'm', 'reading,playing', 'Penguins.jpg', '1996-10-10 00:00:00', 2147483647),
(16, 'shubham', 'shubhamgabale@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 6547896541, 'm', 'singin', 'Lighthouse.jpg', '1995-11-19 00:00:00', 2147483647),
(17, 'sheetal', 'sheetalhendre@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 9865471235, 'f', 'reading', 'Tulips.jpg', '1995-02-25 00:00:00', 2147483647),
(18, 'sarika', 'sarikawathore@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 7845126589, 'f', 'reading,singin', 'Hydrangeas.jpg', '1993-02-14 00:00:00', 2147483647),
(19, 'shrutuika', 'shrutuikamayaskar@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 8545789589, 'm', 'reading', 'Chrysanthemum.jpg', '1994-08-17 00:00:00', 2147483647),
(20, 'keadr lakhane', 'keadrl1995@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 8745457878, 'm', 'reading', 'Desert.jpg', '1977-10-18 00:00:00', 2147483647);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`notice_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);
ALTER TABLE `user` ADD FULLTEXT KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `notice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
