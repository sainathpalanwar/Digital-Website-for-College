--
-- Database: `poll`
--

-- --------------------------------------------------------

--
-- Table structure for table `mst_admin`
--

CREATE TABLE `mst_admin` (
  `loginid` varchar(20) DEFAULT NULL,
  `pass` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_admin`
--

INSERT INTO `mst_admin` (`loginid`, `pass`) VALUES
('admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `mst_question`
--

CREATE TABLE `mst_question` (
  `que_id` int(5) NOT NULL,
  `test_id` int(5) DEFAULT NULL,
  `que_desc` varchar(250) DEFAULT NULL,
  `ans1` varchar(150) DEFAULT NULL,
  `ans2` varchar(150) DEFAULT NULL,
  `ans3` varchar(150) DEFAULT NULL,
  `ans4` varchar(150) DEFAULT NULL,
  `true_ans` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_question`
--

INSERT INTO `mst_question` (`que_id`, `test_id`, `que_desc`, `ans1`, `ans2`, `ans3`, `ans4`, `true_ans`) VALUES
(32, 12, '1. What does PHP stand for?\r\ni) Personal Home Page\r\nii) Hypertext Preprocessor\r\niii) Pretext Hypertext Processor\r\niv) Preprocessor Home Page', 'Both (i) and (ii)', 'Both (ii) and (iv)', 'Only (ii)', 'Both (i) and (iii)', 1),
(33, 12, 'A PHP script should start with ___ and end with ___:', '< php >', '< ?   php ?>', '< ? ? >', '< ? php  ? >', 4),
(34, 12, 'PHP’s numerically indexed array begin with position __.', '1', '2', '0', '-1', 3),
(35, 12, 'Which of the functions is used to sort an array in descending order?', 'sort()', 'asort()', 'rsort()', 'dsort()', 3),
(36, 12, 'Which of the following are correct ways of creating an array?\r\n(i) state[0] = “karnataka”;\r\n(ii) $state[] = array(“karnataka”);\r\n(iii) $state[0] = “ka', '(iii) and (iv)', '(ii) and (iii)', 'Only (i)', '(ii), (iii) and (iv)', 1),
(37, 12, 'What will be the output of the following PHP code?\r\n< ?php \r\n    $fruits = array ("mango", "apple", "pear", "peach");\r\n    $fruits = array_flip($fruit', 'mango', 'Error', 'peach', '0', 2),
(38, 12, 'What will be the output of the following php code?\r\n\r\n< ?php \r\n    $states = array("karnataka" => array\r\n    ( "population" => "11,35,000", "captial" ', ' karnataka 11,35,000', '11,35,000', 'population 11,35,000', 'karnataka population', 2),
(39, 12, 'How many error levels are available in PHP?', '14', '15', '16', '17', 3),
(40, 12, 'What is the description of Error level E_ERROR?', 'Fatal run-time error', 'Near-fatal error', 'Compile-time error', 'Fatal Compile-time error', 1),
(41, 12, 'Which character do the error_reporting directive use to represent the logical operator NOT?', '/', '!', '~', '^', 3),
(42, 12, 'Which one of the following databases has PHP supported almost since the beginning?', 'Oracle Database', 'SQL', 'SQL+', 'MySQL', 4),
(43, 12, 'Which one of the following statements is used to create a table?', 'CREATE TABLE table_name (column_name column_type);', 'CREATE table_name (column_type column_name);', 'CREATE table_name (column_name column_type);', 'CREATE TABLE table_name (column_type column_name);', 1),
(44, 12, 'Which one of the following PHP functions can be used to build a function that accepts any number of arguments?', 'func_get_argv()', 'func_get_argc()', 'get_argv()', 'get_argc()', 2),
(45, 12, 'Which one of the following PHP functions can be used to find files?', 'glob()', 'file()', 'fold()', 'get_file()', 1),
(46, 12, 'The filesize() function returns the file size in ___.', 'bits', 'bytes', 'kilobytes', 'gigabytes', 2),
(47, 12, 'Which one of the following PHP function is used to determine a file’s last access time?', 'fileltime()', 'filectime()', 'fileatime()', 'filetime()', 3),
(48, 12, 'Which one of the following function is capable of reading a file into an array?', 'file()', 'arrfile()', 'arr_file()', 'file_arr()', 1),
(50, 12, 'What will be the output of the following PHP code?\r\n< ?php \r\n   echo str_pad("Salad", 5)." is good.";\r\n?>', 'SaladSaladSaladSaladSalad is good', 'is good SaladSaladSaladSaladSalad', 'is good Salad', 'Salad is good', 4),
(51, 12, 'Which method scope prevents a method from being overridden by a subclass?', 'Abstract', 'Protected', 'Final', 'Static', 3);

-- --------------------------------------------------------

--
-- Table structure for table `mst_result`
--

CREATE TABLE `mst_result` (
  `login` varchar(20) DEFAULT NULL,
  `test_id` int(5) DEFAULT NULL,
  `test_date` date DEFAULT NULL,
  `score` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_result`
--

INSERT INTO `mst_result` (`login`, `test_id`, `test_date`, `score`) VALUES
('S1032130173', 12, '0000-00-00', 5),
('S1032130173', 12, '0000-00-00', 7),
('S1032130522', 12, '0000-00-00', 6),
('sainath', 12, '0000-00-00', 9),
('sainath', 12, '0000-00-00', 7),
('S1032160336', 12, '0000-00-00', 7);

-- --------------------------------------------------------

--
-- Table structure for table `mst_subject`
--

CREATE TABLE `mst_subject` (
  `sub_id` int(5) NOT NULL,
  `sub_name` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_subject`
--

INSERT INTO `mst_subject` (`sub_id`, `sub_name`) VALUES
(8, 'PHP'),
(9, 'JAVA');

-- --------------------------------------------------------

--
-- Table structure for table `mst_test`
--

CREATE TABLE `mst_test` (
  `test_id` int(5) NOT NULL,
  `sub_id` int(5) DEFAULT NULL,
  `test_name` varchar(30) DEFAULT NULL,
  `total_que` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_test`
--

INSERT INTO `mst_test` (`test_id`, `sub_id`, `test_name`, `total_que`) VALUES
(12, 8, 'php practics', '20'),
(13, 9, 'java Practics', '20');

-- --------------------------------------------------------

--
-- Table structure for table `mst_user`
--

CREATE TABLE `mst_user` (
  `user_id` int(5) NOT NULL,
  `login` varchar(20) DEFAULT NULL,
  `pass` varchar(20) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `city` varchar(15) DEFAULT NULL,
  `phone` int(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_user`
--

INSERT INTO `mst_user` (`user_id`, `login`, `pass`, `username`, `address`, `city`, `phone`, `email`) VALUES
(15, 'sainath', 'Sai@9860', 'sainath', 'nanded', 'nanded', 2147483647, 'palanwars@gmail.com'),
(16, 'S1032160336', 'Sai@9860', 'sainath palanwar', 'becse1', 'nanded', 2147483647, 'palanwars@gmail.com'),
(17, 'S1032130173', 'S1032130173', 'Avinash Kanjalkar', 'BECSE1', 'Nanded', 2147483647, 'avikanjalkar335@gmail.com'),
(18, '8446537605', 'sumashri07', 'Sumashri', 'BE', 'Nanded', 2147483647, 'sumashril100@gmail.com'),
(19, 'S1032130236', 'abcdef', 'Shrutika Myskar', 'BE CSE-1', 'Nanded', 2147483647, 'abcde.xyz@gmail.com'),
(20, 'S1032140354', 'pragati11', 'Pragati manoorkar', 'Becse', 'Nanded', 2147483647, 'Pragatimanoorkar1128@gmail'),
(21, 's1032140088', 'hash96', 'Furkhan hashmi', 'becse1', 'nanded', 2147483647, 'marshalrap96@gmail.com'),
(22, 'S1032140033', 'S1032140033', 'vaishnavi channawar', 'BECSE1', 'nanded', 2147483647, 'vaishnavi@gmail.com'),
(23, 'S1032140221', 'kedar', 'Kedar Penurkar', 'Be cse1', 'Nanded', 2147483647, 'kedarpenurkar@gmail.com'),
(24, 'S1032140360', 'navle', 'Dk navle', 'Be cse1', 'Nanded', 2147483647, 'Dknavle5@gmail.com'),
(25, 'S1032130074', '47854785', 'Ankita Damkondwar ', 'BE', 'Nanded', 2147483647, 'ankita.damkondwar@gmail.com'),
(26, 'S1032130262', 'arp', 'Abhishek Pardeshi', 'Be', 'Nanded ', 2147483647, 'arp7887@gmail.com'),
(27, 'S1032140173', 'mayuri11', 'Mayuri maheshwar menkudle', 'Becse1', 'Nanded', 2147483647, 'mmmenkudle@gmail.com'),
(28, 'S1032140004', 'swati123', 'Swati Sambhaji Amrute', 'BE', 'Nanded', 2147483647, 'swatiamrute111@gmail.com'),
(29, 's1032140353', 'madhuri24', 'Lokade Madhuri Madhavrao', 'BE CSE1', 'Nanded', 2147483647, 'madhulokade1@gmail.com'),
(30, 'S1032140160', 'S1032140160', 'swati malode ', 'Becse1', 'Nanded', 2147483647, 'Swatimalode37@gmail.com'),
(31, 'S1032130246', 'megha', 'megha nathani', 'becse1', 'nanded', 987657899, 'meghanathani166@gmail.com'),
(32, 'S1032130522', 'Nikhil@1234', 'nikhil dewne', 'becse2', 'nanded', 2147483647, 'nikhildewne@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `mst_useranswer`
--

CREATE TABLE `mst_useranswer` (
  `sess_id` varchar(80) DEFAULT NULL,
  `test_id` int(11) DEFAULT NULL,
  `que_des` varchar(200) DEFAULT NULL,
  `ans1` varchar(50) DEFAULT NULL,
  `ans2` varchar(50) DEFAULT NULL,
  `ans3` varchar(50) DEFAULT NULL,
  `ans4` varchar(50) DEFAULT NULL,
  `true_ans` int(11) DEFAULT NULL,
  `your_ans` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_useranswer`
--

INSERT INTO `mst_useranswer` (`sess_id`, `test_id`, `que_des`, `ans1`, `ans2`, `ans3`, `ans4`, `true_ans`, `your_ans`) VALUES
('kcmek2qgne6a50kao5ka2spomr', 12, '1. What does PHP stand for?\r\ni) Personal Home Page\r\nii) Hypertext Preprocessor\r\niii) Pretext Hypertext Processor\r\niv) Preprocessor Home Page', 'Both (i) and (ii)', 'Both (ii) and (iv)', 'Only (ii)', 'Both (i) and (iii)', 1, 1),
('kcmek2qgne6a50kao5ka2spomr', 12, 'A PHP script should start with ___ and end with ___:', '< php >', '< ?   php ?>', '< ? ? >', '<?php  ? >', 4, 4),
('kcmek2qgne6a50kao5ka2spomr', 12, 'PHP’s numerically indexed array begin with position __.', '1', '2', '0', '-1', 3, 3),
('kcmek2qgne6a50kao5ka2spomr', 12, 'Which of the functions is used to sort an array in descending order?', 'sort()', 'asort()', 'rsort()', 'dsort()', 3, 3),
('vjdms99qcouhfiqndtfft05d0o', 12, '1. What does PHP stand for?\r\ni) Personal Home Page\r\nii) Hypertext Preprocessor\r\niii) Pretext Hypertext Processor\r\niv) Preprocessor Home Page', 'Both (i) and (ii)', 'Both (ii) and (iv)', 'Only (ii)', 'Both (i) and (iii)', 1, 1),
('vjdms99qcouhfiqndtfft05d0o', 12, 'A PHP script should start with ___ and end with ___:', '< php >', '< ?   php ?>', '< ? ? >', '< ? php  ? >', 4, 1),
('vjdms99qcouhfiqndtfft05d0o', 12, 'PHP’s numerically indexed array begin with position __.', '1', '2', '0', '-1', 3, 3),
('vjdms99qcouhfiqndtfft05d0o', 12, 'Which of the functions is used to sort an array in descending order?', 'sort()', 'asort()', 'rsort()', 'dsort()', 3, 2),
('vjdms99qcouhfiqndtfft05d0o', 12, 'Which of the following are correct ways of creating an array?\r\n(i) state[0] = “karnataka”;\r\n(ii) $state[] = array(“karnataka”);\r\n(iii) $state[0] = “ka', '(iii) and (iv)', '(ii) and (iii)', 'Only (i)', '(ii), (iii) and (iv)', 1, 2),
('vjdms99qcouhfiqndtfft05d0o', 12, 'What will be the output of the following PHP code?\r\n< ?php \r\n    $fruits = array ("mango", "apple", "pear", "peach");\r\n    $fruits = array_flip($fruit', 'mango', 'Error', 'peach', '0', 2, 3),
('vjdms99qcouhfiqndtfft05d0o', 12, 'What will be the output of the following php code?\r\n\r\n< ?php \r\n    $states = array("karnataka" => array\r\n    ( "population" => "11,35,000", "captial" ', ' karnataka 11,35,000', '11,35,000', 'population 11,35,000', 'karnataka population', 2, 2),
('vjdms99qcouhfiqndtfft05d0o', 12, 'How many error levels are available in PHP?', '14', '15', '16', '17', 3, 3),
('vjdms99qcouhfiqndtfft05d0o', 12, 'What is the description of Error level E_ERROR?', 'Fatal run-time error', 'Near-fatal error', 'Compile-time error', 'Fatal Compile-time error', 1, 2),
('vjdms99qcouhfiqndtfft05d0o', 12, 'Which character do the error_reporting directive use to represent the logical operator NOT?', '/', '!', '~', '^', 3, 1),
('vjdms99qcouhfiqndtfft05d0o', 12, 'Which one of the following databases has PHP supported almost since the beginning?', 'Oracle Database', 'SQL', 'SQL+', 'MySQL', 4, 2),
('vjdms99qcouhfiqndtfft05d0o', 12, 'Which one of the following statements is used to create a table?', 'CREATE TABLE table_name (column_name column_type);', 'CREATE table_name (column_type column_name);', 'CREATE table_name (column_name column_type);', 'CREATE TABLE table_name (column_type column_name);', 1, 2),
('vjdms99qcouhfiqndtfft05d0o', 12, 'Which one of the following PHP functions can be used to build a function that accepts any number of arguments?', 'func_get_argv()', 'func_get_argc()', 'get_argv()', 'get_argc()', 2, 3),
('vjdms99qcouhfiqndtfft05d0o', 12, 'Which one of the following PHP functions can be used to find files?', 'glob()', 'file()', 'fold()', 'get_file()', 1, 4),
('vjdms99qcouhfiqndtfft05d0o', 12, 'The filesize() function returns the file size in ___.', 'bits', 'bytes', 'kilobytes', 'gigabytes', 2, 3),
('vjdms99qcouhfiqndtfft05d0o', 12, 'Which one of the following PHP function is used to determine a file’s last access time?', 'fileltime()', 'filectime()', 'fileatime()', 'filetime()', 3, 3),
('vjdms99qcouhfiqndtfft05d0o', 12, 'Which one of the following function is capable of reading a file into an array?', 'file()', 'arrfile()', 'arr_file()', 'file_arr()', 1, 4),
('vjdms99qcouhfiqndtfft05d0o', 12, 'What will be the output of the following PHP code?\r\n< ?php \r\n   echo str_pad("Salad", 5)." is good.";\r\n?>', 'SaladSaladSaladSaladSalad is good', 'is good SaladSaladSaladSaladSalad', 'is good Salad', 'Salad is good', 4, 4),
('vjdms99qcouhfiqndtfft05d0o', 12, 'Which method scope prevents a method from being overridden by a subclass?', 'Abstract', 'Protected', 'Final', 'Static', 3, 3),
('fehi1a93lovqpj91mls7l7q90t', 12, '1. What does PHP stand for?\r\ni) Personal Home Page\r\nii) Hypertext Preprocessor\r\niii) Pretext Hypertext Processor\r\niv) Preprocessor Home Page', 'Both (i) and (ii)', 'Both (ii) and (iv)', 'Only (ii)', 'Both (i) and (iii)', 1, 1),
('fehi1a93lovqpj91mls7l7q90t', 12, 'A PHP script should start with ___ and end with ___:', '< php >', '< ?   php ?>', '< ? ? >', '< ? php  ? >', 4, 4),
('fehi1a93lovqpj91mls7l7q90t', 12, 'PHP’s numerically indexed array begin with position __.', '1', '2', '0', '-1', 3, 3),
('l3h1g7a1dvvbm76349bt2sqaq4', 12, '1. What does PHP stand for?\r\ni) Personal Home Page\r\nii) Hypertext Preprocessor\r\niii) Pretext Hypertext Processor\r\niv) Preprocessor Home Page', 'Both (i) and (ii)', 'Both (ii) and (iv)', 'Only (ii)', 'Both (i) and (iii)', 1, 1),
('8kle2dh7ukg87o3cuguejt1qn7', 12, '1. What does PHP stand for?\r\ni) Personal Home Page\r\nii) Hypertext Preprocessor\r\niii) Pretext Hypertext Processor\r\niv) Preprocessor Home Page', 'Both (i) and (ii)', 'Both (ii) and (iv)', 'Only (ii)', 'Both (i) and (iii)', 1, 3),
('8kle2dh7ukg87o3cuguejt1qn7', 12, 'A PHP script should start with ___ and end with ___:', '< php >', '< ?   php ?>', '< ? ? >', '< ? php  ? >', 4, 2),
('8kle2dh7ukg87o3cuguejt1qn7', 12, 'PHP’s numerically indexed array begin with position __.', '1', '2', '0', '-1', 3, 4),
('8kle2dh7ukg87o3cuguejt1qn7', 12, 'Which of the functions is used to sort an array in descending order?', 'sort()', 'asort()', 'rsort()', 'dsort()', 3, 1),
('8kle2dh7ukg87o3cuguejt1qn7', 12, 'Which of the following are correct ways of creating an array?\r\n(i) state[0] = “karnataka”;\r\n(ii) $state[] = array(“karnataka”);\r\n(iii) $state[0] = “ka', '(iii) and (iv)', '(ii) and (iii)', 'Only (i)', '(ii), (iii) and (iv)', 1, 2),
('8kle2dh7ukg87o3cuguejt1qn7', 12, 'What will be the output of the following PHP code?\r\n< ?php \r\n    $fruits = array ("mango", "apple", "pear", "peach");\r\n    $fruits = array_flip($fruit', 'mango', 'Error', 'peach', '0', 2, 4),
('8kle2dh7ukg87o3cuguejt1qn7', 12, 'What will be the output of the following php code?\r\n\r\n< ?php \r\n    $states = array("karnataka" => array\r\n    ( "population" => "11,35,000", "captial" ', ' karnataka 11,35,000', '11,35,000', 'population 11,35,000', 'karnataka population', 2, 2),
('8kle2dh7ukg87o3cuguejt1qn7', 12, 'How many error levels are available in PHP?', '14', '15', '16', '17', 3, 3),
('8kle2dh7ukg87o3cuguejt1qn7', 12, 'What is the description of Error level E_ERROR?', 'Fatal run-time error', 'Near-fatal error', 'Compile-time error', 'Fatal Compile-time error', 1, 1),
('8kle2dh7ukg87o3cuguejt1qn7', 12, 'Which character do the error_reporting directive use to represent the logical operator NOT?', '/', '!', '~', '^', 3, 2),
('8kle2dh7ukg87o3cuguejt1qn7', 12, 'Which one of the following databases has PHP supported almost since the beginning?', 'Oracle Database', 'SQL', 'SQL+', 'MySQL', 4, 2),
('8kle2dh7ukg87o3cuguejt1qn7', 12, 'Which one of the following statements is used to create a table?', 'CREATE TABLE table_name (column_name column_type);', 'CREATE table_name (column_type column_name);', 'CREATE table_name (column_name column_type);', 'CREATE TABLE table_name (column_type column_name);', 1, 1),
('8kle2dh7ukg87o3cuguejt1qn7', 12, 'Which one of the following PHP functions can be used to build a function that accepts any number of arguments?', 'func_get_argv()', 'func_get_argc()', 'get_argv()', 'get_argc()', 2, 2),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, '1. What does PHP stand for?\r\ni) Personal Home Page\r\nii) Hypertext Preprocessor\r\niii) Pretext Hypertext Processor\r\niv) Preprocessor Home Page', 'Both (i) and (ii)', 'Both (ii) and (iv)', 'Only (ii)', 'Both (i) and (iii)', 1, 3),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'A PHP script should start with ___ and end with ___:', '< php >', '< ?   php ?>', '< ? ? >', '< ? php  ? >', 4, 4),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'PHP’s numerically indexed array begin with position __.', '1', '2', '0', '-1', 3, 3),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'Which of the functions is used to sort an array in descending order?', 'sort()', 'asort()', 'rsort()', 'dsort()', 3, 3),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'Which of the following are correct ways of creating an array?\r\n(i) state[0] = “karnataka”;\r\n(ii) $state[] = array(“karnataka”);\r\n(iii) $state[0] = “ka', '(iii) and (iv)', '(ii) and (iii)', 'Only (i)', '(ii), (iii) and (iv)', 1, 3),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'What will be the output of the following PHP code?\r\n< ?php \r\n    $fruits = array ("mango", "apple", "pear", "peach");\r\n    $fruits = array_flip($fruit', 'mango', 'Error', 'peach', '0', 2, 2),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'What will be the output of the following php code?\r\n\r\n< ?php \r\n    $states = array("karnataka" => array\r\n    ( "population" => "11,35,000", "captial" ', ' karnataka 11,35,000', '11,35,000', 'population 11,35,000', 'karnataka population', 2, 3),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'How many error levels are available in PHP?', '14', '15', '16', '17', 3, 2),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'What is the description of Error level E_ERROR?', 'Fatal run-time error', 'Near-fatal error', 'Compile-time error', 'Fatal Compile-time error', 1, 3),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'Which character do the error_reporting directive use to represent the logical operator NOT?', '/', '!', '~', '^', 3, 3),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'Which one of the following databases has PHP supported almost since the beginning?', 'Oracle Database', 'SQL', 'SQL+', 'MySQL', 4, 3),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'Which one of the following statements is used to create a table?', 'CREATE TABLE table_name (column_name column_type);', 'CREATE table_name (column_type column_name);', 'CREATE table_name (column_name column_type);', 'CREATE TABLE table_name (column_type column_name);', 1, 3),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'Which one of the following PHP functions can be used to build a function that accepts any number of arguments?', 'func_get_argv()', 'func_get_argc()', 'get_argv()', 'get_argc()', 2, 3),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'Which one of the following PHP functions can be used to find files?', 'glob()', 'file()', 'fold()', 'get_file()', 1, 2),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'The filesize() function returns the file size in ___.', 'bits', 'bytes', 'kilobytes', 'gigabytes', 2, 4),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'Which one of the following PHP function is used to determine a file’s last access time?', 'fileltime()', 'filectime()', 'fileatime()', 'filetime()', 3, 3),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'Which one of the following function is capable of reading a file into an array?', 'file()', 'arrfile()', 'arr_file()', 'file_arr()', 1, 3),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'What will be the output of the following PHP code?\r\n< ?php \r\n   echo str_pad("Salad", 5)." is good.";\r\n?>', 'SaladSaladSaladSaladSalad is good', 'is good SaladSaladSaladSaladSalad', 'is good Salad', 'Salad is good', 4, 1),
('pekiu9sh8jo0rf5vqbtd3oqunl', 12, 'Which method scope prevents a method from being overridden by a subclass?', 'Abstract', 'Protected', 'Final', 'Static', 3, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, '1. What does PHP stand for?\r\ni) Personal Home Page\r\nii) Hypertext Preprocessor\r\niii) Pretext Hypertext Processor\r\niv) Preprocessor Home Page', 'Both (i) and (ii)', 'Both (ii) and (iv)', 'Only (ii)', 'Both (i) and (iii)', 1, 1),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'A PHP script should start with ___ and end with ___:', '< php >', '< ?   php ?>', '< ? ? >', '< ? php  ? >', 4, 4),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'PHP’s numerically indexed array begin with position __.', '1', '2', '0', '-1', 3, 3),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which of the functions is used to sort an array in descending order?', 'sort()', 'asort()', 'rsort()', 'dsort()', 3, 3),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which of the following are correct ways of creating an array?\r\n(i) state[0] = “karnataka”;\r\n(ii) $state[] = array(“karnataka”);\r\n(iii) $state[0] = “ka', '(iii) and (iv)', '(ii) and (iii)', 'Only (i)', '(ii), (iii) and (iv)', 1, 1),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'What will be the output of the following PHP code?\r\n< ?php \r\n    $fruits = array ("mango", "apple", "pear", "peach");\r\n    $fruits = array_flip($fruit', 'mango', 'Error', 'peach', '0', 2, 1),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'What will be the output of the following php code?\r\n\r\n< ?php \r\n    $states = array("karnataka" => array\r\n    ( "population" => "11,35,000", "captial" ', ' karnataka 11,35,000', '11,35,000', 'population 11,35,000', 'karnataka population', 2, 1),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'How many error levels are available in PHP?', '14', '15', '16', '17', 3, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'What is the description of Error level E_ERROR?', 'Fatal run-time error', 'Near-fatal error', 'Compile-time error', 'Fatal Compile-time error', 1, 3),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which character do the error_reporting directive use to represent the logical operator NOT?', '/', '!', '~', '^', 3, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which one of the following databases has PHP supported almost since the beginning?', 'Oracle Database', 'SQL', 'SQL+', 'MySQL', 4, 4),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which one of the following statements is used to create a table?', 'CREATE TABLE table_name (column_name column_type);', 'CREATE table_name (column_type column_name);', 'CREATE table_name (column_name column_type);', 'CREATE TABLE table_name (column_type column_name);', 1, 4),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which one of the following PHP functions can be used to build a function that accepts any number of arguments?', 'func_get_argv()', 'func_get_argc()', 'get_argv()', 'get_argc()', 2, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which one of the following PHP functions can be used to find files?', 'glob()', 'file()', 'fold()', 'get_file()', 1, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'The filesize() function returns the file size in ___.', 'bits', 'bytes', 'kilobytes', 'gigabytes', 2, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which one of the following PHP function is used to determine a file’s last access time?', 'fileltime()', 'filectime()', 'fileatime()', 'filetime()', 3, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which one of the following function is capable of reading a file into an array?', 'file()', 'arrfile()', 'arr_file()', 'file_arr()', 1, 3),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'What will be the output of the following PHP code?\r\n< ?php \r\n   echo str_pad("Salad", 5)." is good.";\r\n?>', 'SaladSaladSaladSaladSalad is good', 'is good SaladSaladSaladSaladSalad', 'is good Salad', 'Salad is good', 4, 1),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which method scope prevents a method from being overridden by a subclass?', 'Abstract', 'Protected', 'Final', 'Static', 3, 1),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, '1. What does PHP stand for?\r\ni) Personal Home Page\r\nii) Hypertext Preprocessor\r\niii) Pretext Hypertext Processor\r\niv) Preprocessor Home Page', 'Both (i) and (ii)', 'Both (ii) and (iv)', 'Only (ii)', 'Both (i) and (iii)', 1, 1),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, '1. What does PHP stand for?\r\ni) Personal Home Page\r\nii) Hypertext Preprocessor\r\niii) Pretext Hypertext Processor\r\niv) Preprocessor Home Page', 'Both (i) and (ii)', 'Both (ii) and (iv)', 'Only (ii)', 'Both (i) and (iii)', 1, 1),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'A PHP script should start with ___ and end with ___:', '< php >', '< ?   php ?>', '< ? ? >', '< ? php  ? >', 4, 4),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'PHP’s numerically indexed array begin with position __.', '1', '2', '0', '-1', 3, 3),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which of the functions is used to sort an array in descending order?', 'sort()', 'asort()', 'rsort()', 'dsort()', 3, 3),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which of the following are correct ways of creating an array?\r\n(i) state[0] = “karnataka”;\r\n(ii) $state[] = array(“karnataka”);\r\n(iii) $state[0] = “ka', '(iii) and (iv)', '(ii) and (iii)', 'Only (i)', '(ii), (iii) and (iv)', 1, 3),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'What will be the output of the following PHP code?\r\n< ?php \r\n    $fruits = array ("mango", "apple", "pear", "peach");\r\n    $fruits = array_flip($fruit', 'mango', 'Error', 'peach', '0', 2, 3),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'What will be the output of the following php code?\r\n\r\n< ?php \r\n    $states = array("karnataka" => array\r\n    ( "population" => "11,35,000", "captial" ', ' karnataka 11,35,000', '11,35,000', 'population 11,35,000', 'karnataka population', 2, 4),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'How many error levels are available in PHP?', '14', '15', '16', '17', 3, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'What is the description of Error level E_ERROR?', 'Fatal run-time error', 'Near-fatal error', 'Compile-time error', 'Fatal Compile-time error', 1, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which character do the error_reporting directive use to represent the logical operator NOT?', '/', '!', '~', '^', 3, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which one of the following databases has PHP supported almost since the beginning?', 'Oracle Database', 'SQL', 'SQL+', 'MySQL', 4, 4),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which one of the following statements is used to create a table?', 'CREATE TABLE table_name (column_name column_type);', 'CREATE table_name (column_type column_name);', 'CREATE table_name (column_name column_type);', 'CREATE TABLE table_name (column_type column_name);', 1, 4),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which one of the following PHP functions can be used to build a function that accepts any number of arguments?', 'func_get_argv()', 'func_get_argc()', 'get_argv()', 'get_argc()', 2, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which one of the following PHP functions can be used to find files?', 'glob()', 'file()', 'fold()', 'get_file()', 1, 3),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'The filesize() function returns the file size in ___.', 'bits', 'bytes', 'kilobytes', 'gigabytes', 2, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which one of the following PHP function is used to determine a file’s last access time?', 'fileltime()', 'filectime()', 'fileatime()', 'filetime()', 3, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which one of the following function is capable of reading a file into an array?', 'file()', 'arrfile()', 'arr_file()', 'file_arr()', 1, 4),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'What will be the output of the following PHP code?\r\n< ?php \r\n   echo str_pad("Salad", 5)." is good.";\r\n?>', 'SaladSaladSaladSaladSalad is good', 'is good SaladSaladSaladSaladSalad', 'is good Salad', 'Salad is good', 4, 2),
('4fqhhval9eghg2v1rj4n5m1nrk', 12, 'Which method scope prevents a method from being overridden by a subclass?', 'Abstract', 'Protected', 'Final', 'Static', 3, 2),
('4bje52kq131udmr9dsg1o2epl6', 12, '1. What does PHP stand for?\r\ni) Personal Home Page\r\nii) Hypertext Preprocessor\r\niii) Pretext Hypertext Processor\r\niv) Preprocessor Home Page', 'Both (i) and (ii)', 'Both (ii) and (iv)', 'Only (ii)', 'Both (i) and (iii)', 1, 4),
('4bje52kq131udmr9dsg1o2epl6', 12, 'A PHP script should start with ___ and end with ___:', '< php >', '< ?   php ?>', '< ? ? >', '< ? php  ? >', 4, 4),
('4bje52kq131udmr9dsg1o2epl6', 12, 'PHP’s numerically indexed array begin with position __.', '1', '2', '0', '-1', 3, 3),
('4bje52kq131udmr9dsg1o2epl6', 12, 'Which of the functions is used to sort an array in descending order?', 'sort()', 'asort()', 'rsort()', 'dsort()', 3, 3),
('4bje52kq131udmr9dsg1o2epl6', 12, 'Which of the following are correct ways of creating an array?\r\n(i) state[0] = “karnataka”;\r\n(ii) $state[] = array(“karnataka”);\r\n(iii) $state[0] = “ka', '(iii) and (iv)', '(ii) and (iii)', 'Only (i)', '(ii), (iii) and (iv)', 1, 4),
('4bje52kq131udmr9dsg1o2epl6', 12, 'What will be the output of the following PHP code?\r\n< ?php \r\n    $fruits = array ("mango", "apple", "pear", "peach");\r\n    $fruits = array_flip($fruit', 'mango', 'Error', 'peach', '0', 2, 2),
('4bje52kq131udmr9dsg1o2epl6', 12, 'What will be the output of the following php code?\r\n\r\n< ?php \r\n    $states = array("karnataka" => array\r\n    ( "population" => "11,35,000", "captial" ', ' karnataka 11,35,000', '11,35,000', 'population 11,35,000', 'karnataka population', 2, 1),
('4bje52kq131udmr9dsg1o2epl6', 12, 'How many error levels are available in PHP?', '14', '15', '16', '17', 3, 3),
('4bje52kq131udmr9dsg1o2epl6', 12, 'What is the description of Error level E_ERROR?', 'Fatal run-time error', 'Near-fatal error', 'Compile-time error', 'Fatal Compile-time error', 1, 2),
('4bje52kq131udmr9dsg1o2epl6', 12, 'Which character do the error_reporting directive use to represent the logical operator NOT?', '/', '!', '~', '^', 3, 2),
('4bje52kq131udmr9dsg1o2epl6', 12, 'Which one of the following databases has PHP supported almost since the beginning?', 'Oracle Database', 'SQL', 'SQL+', 'MySQL', 4, 4),
('4bje52kq131udmr9dsg1o2epl6', 12, 'Which one of the following statements is used to create a table?', 'CREATE TABLE table_name (column_name column_type);', 'CREATE table_name (column_type column_name);', 'CREATE table_name (column_name column_type);', 'CREATE TABLE table_name (column_type column_name);', 1, 4),
('4bje52kq131udmr9dsg1o2epl6', 12, 'Which one of the following PHP functions can be used to build a function that accepts any number of arguments?', 'func_get_argv()', 'func_get_argc()', 'get_argv()', 'get_argc()', 2, 3),
('4bje52kq131udmr9dsg1o2epl6', 12, 'Which one of the following PHP functions can be used to find files?', 'glob()', 'file()', 'fold()', 'get_file()', 1, 4),
('4bje52kq131udmr9dsg1o2epl6', 12, 'The filesize() function returns the file size in ___.', 'bits', 'bytes', 'kilobytes', 'gigabytes', 2, 3),
('4bje52kq131udmr9dsg1o2epl6', 12, 'Which one of the following PHP function is used to determine a file’s last access time?', 'fileltime()', 'filectime()', 'fileatime()', 'filetime()', 3, 4),
('4bje52kq131udmr9dsg1o2epl6', 12, 'Which one of the following function is capable of reading a file into an array?', 'file()', 'arrfile()', 'arr_file()', 'file_arr()', 1, 4),
('4bje52kq131udmr9dsg1o2epl6', 12, 'What will be the output of the following PHP code?\r\n< ?php \r\n   echo str_pad("Salad", 5)." is good.";\r\n?>', 'SaladSaladSaladSaladSalad is good', 'is good SaladSaladSaladSaladSalad', 'is good Salad', 'Salad is good', 4, 3),
('4bje52kq131udmr9dsg1o2epl6', 12, 'Which method scope prevents a method from being overridden by a subclass?', 'Abstract', 'Protected', 'Final', 'Static', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `student_table`
--

CREATE TABLE `student_table` (
  `std_roll_no` int(11) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `Session` varchar(50) NOT NULL,
  `Program` varchar(50) NOT NULL,
  `Semester` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_table`
--

INSERT INTO `student_table` (`std_roll_no`, `student_name`, `dob`, `gender`, `email`, `phone`, `address`, `Session`, `Program`, `Semester`) VALUES
(1, 'Sainath Palanwar', '1995-06-01', 'male', 'palanwars@gmail.com', '8381099576', 'nanded', 'morning', 'BE', '8th'),
(2, 'sumashri ', '1996-11-07', 'female', 'sumashril100@gmail.com', '8787878787', 'nanded', 'mo', 'BE', '8th'),
(3, 'shrutika mayaskar', '2018-05-17', 'female', 'shrum@gmail.com', '1234321234', 'nanded', 'regular', '8th', 'BE');

-- --------------------------------------------------------

--
-- Table structure for table `subject_table`
--

CREATE TABLE `subject_table` (
  `subject_no` int(11) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `field` varchar(10) NOT NULL,
  `semester` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject_table`
--

INSERT INTO `subject_table` (`subject_no`, `subject_name`, `teacher_name`, `field`, `semester`) VALUES
(2, 'MOC', 'Chinnoji sir', 'BE', '8th'),
(3, 'BIG DATA', 'Jagalpure', 'BE', '8th'),
(4, 'ML', 'Pande', 'BE', '8th'),
(5, 'HCI', 'Naik', 'BE', '8th'),
(6, 'CC', 'Kale', 'BE', '8th'),
(7, 'CNS', 'Titare', 'BE', '8th'),
(8, 'DS', 'Pariyal', 'BE', '8th');

-- --------------------------------------------------------

--
-- Table structure for table `tbadministrators`
--

CREATE TABLE `tbadministrators` (
  `admin_id` int(5) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbadministrators`
--

INSERT INTO `tbadministrators` (`admin_id`, `first_name`, `last_name`, `email`, `password`) VALUES
(1, 'sainath', 'palanwar', 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbcandidates`
--

CREATE TABLE `tbcandidates` (
  `candidate_id` int(5) NOT NULL,
  `candidate_name` varchar(45) NOT NULL,
  `candidate_position` varchar(45) NOT NULL,
  `candidate_cvotes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbcandidates`
--

INSERT INTO `tbcandidates` (`candidate_id`, `candidate_name`, `candidate_position`, `candidate_cvotes`) VALUES
(1, 'Sumashri Landge', 'LR', 3),
(2, 'Sheetal Hendre', 'LR', 1),
(3, 'Sarika Watore', 'LR', 1),
(4, 'Sainath Palanwar', 'GS', 2),
(5, 'Avinash Kanjalkar', 'GS', 1),
(6, 'Shreyas Bhoyar', 'GS', 0),
(7, 'Ajit kadam', 'MS', 3),
(8, 'Madhusudhan Kokate', 'MS', 0),
(9, 'Arvind Kumar', 'SS', 1),
(10, 'Kedar Penurkar', 'SS', 0),
(11, 'Vaishnavi Deshmukh', 'CS', 1),
(12, 'Mrinal Patil', 'CS', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendence`
--

CREATE TABLE `tbl_attendence` (
  `attID` int(11) NOT NULL,
  `StudentRollNumber` int(11) NOT NULL,
  `SubjectId` int(11) NOT NULL,
  `Attendence` varchar(11) NOT NULL,
  `Date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_attendence`
--

INSERT INTO `tbl_attendence` (`attID`, `StudentRollNumber`, `SubjectId`, `Attendence`, `Date`) VALUES
(1, 1, 1, 'P', '2018-04-27 09:36:52'),
(2, 1, 1, 'P', '2018-04-27 09:39:36'),
(3, 1, 1, 'P', '2018-04-27 09:39:40'),
(4, 1, 1, 'P', '2018-04-27 09:39:42'),
(5, 1, 1, 'P', '2018-04-27 09:39:44'),
(6, 2, 1, 'P', '2018-04-27 09:40:05'),
(7, 2, 1, 'P', '2018-04-27 09:40:37'),
(8, 1, 1, 'P', '2018-05-10 06:35:52'),
(9, 1, 1, 'A', '2018-05-10 06:36:16'),
(10, 1, 2, 'P', '2018-05-12 07:47:03'),
(11, 2, 5, 'P', '2018-05-12 07:47:26'),
(12, 3, 7, 'P', '2018-05-12 07:47:48'),
(13, 3, 5, 'A', '2018-05-12 07:48:01');

-- --------------------------------------------------------

--
-- Table structure for table `tbmembers`
--

CREATE TABLE `tbmembers` (
  `member_id` int(5) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbmembers`
--

INSERT INTO `tbmembers` (`member_id`, `first_name`, `last_name`, `email`, `password`) VALUES
(1, 'sainath', 'palanwar', 'sai@gmail.com', '1234'),
(2, 'sainath', 'palanwar', 'palanwars@gmail.com', '1234'),
(3, 'sumashri', 'landge', 'sumashril100@gmail.com', '1234'),
(4, 'avinash', 'kanjalkar', 'kanjalkaravi@gmail.com', '1234'),
(5, 'shreyas', 'bhoyar', 'shreyasbhoyar@gmail.com', '1234'),
(6, 'sheetal', 'hendre', 'sheetalhendre@gmail.com', '1234'),
(7, 'sarika', 'wathore', 'sarikawathore@gmail.com', '1234'),
(8, 'shubham', 'gabale', 'shubham@gmail.com', '1234'),
(9, 'keadr', 'lakhane', 'keadrl1995@gmail.com', '1234'),
(10, 'keadr', 'wadje', 'kedarw1995@gmail.com', '1234'),
(11, 'kedar ', 'penurkar', 'kedarp1995@gmail.com', '1234'),
(12, 'dnyashwar', 'kakade', 'dkakade@gmail.com', '1234'),
(13, 'dnyashwar', 'rampure', 'drampure@gmail.com', '1234'),
(14, 'ajit', 'kadam', 'ajitkadam@gmail.com', '1234'),
(15, 'furkhan', 'hasmi', 'hasmifurkhan@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `tbpositions`
--

CREATE TABLE `tbpositions` (
  `position_id` int(5) NOT NULL,
  `position_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbpositions`
--

INSERT INTO `tbpositions` (`position_id`, `position_name`) VALUES
(2, 'LR'),
(3, 'MS'),
(4, 'GS'),
(5, 'SS'),
(6, 'CS');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_table`
--

CREATE TABLE `teacher_table` (
  `teacher_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `degree` varchar(50) NOT NULL,
  `salary` varchar(50) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_table`
--

INSERT INTO `teacher_table` (`teacher_id`, `first_name`, `last_name`, `dob`, `gender`, `email`, `phone`, `degree`, `salary`, `address`) VALUES
(0, 'Mangesh', 'bhandre', '1988-06-14', 'male', 'mangeshbhandre@gmail.com', '1234567890', 'Master', '50000', 'NANDED'),
(0, 'Prof M.R', 'Chennoji', '2018-05-16', 'male', 'chennoji@gmail.com', '12343545545', 'Master', '50000', 'nanded'),
(0, 'Prof S.I.', 'Titare', '2018-05-20', 'male', 'titare@gmail.com', '12343545545', 'M.phil', '50000', 'nanded'),
(0, 'Prof S.A.', 'Jagalpure', '2017-08-16', 'male', 'jagalpure@gmail.com', '1231231231', 'Master', '50000', 'vfgfdg'),
(0, 'Prof Mrs. N.L.', 'Pariyal', '2018-05-22', 'female', 'pariyal@gmail.com', '4343456677', 'P.HD', '50000', 'ghgfhfg'),
(0, 'Prof Mrs. J.S.', 'Kale', '2018-05-29', 'female', 'kale@gmail.com', '1232434324', 'P.HD', '50000', 'dfdvdxv'),
(0, 'Prof Mrs. N.S.', 'Pande', '2018-05-31', 'female', 'pande@gmail.com', '6564454646', 'P.HD', '50000', 'tdgdfgdf'),
(0, 'Prof D.S.', 'Naik', '2018-05-31', 'female', 'naik@gmail.com', '1231231231', 'Master', '50000', 'fvgfgsdf');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin@gmail.com', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mst_question`
--
ALTER TABLE `mst_question`
  ADD PRIMARY KEY (`que_id`);

--
-- Indexes for table `mst_subject`
--
ALTER TABLE `mst_subject`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `mst_test`
--
ALTER TABLE `mst_test`
  ADD PRIMARY KEY (`test_id`);

--
-- Indexes for table `mst_user`
--
ALTER TABLE `mst_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `student_table`
--
ALTER TABLE `student_table`
  ADD PRIMARY KEY (`std_roll_no`);

--
-- Indexes for table `subject_table`
--
ALTER TABLE `subject_table`
  ADD PRIMARY KEY (`subject_no`);

--
-- Indexes for table `tbadministrators`
--
ALTER TABLE `tbadministrators`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbcandidates`
--
ALTER TABLE `tbcandidates`
  ADD PRIMARY KEY (`candidate_id`);

--
-- Indexes for table `tbl_attendence`
--
ALTER TABLE `tbl_attendence`
  ADD PRIMARY KEY (`attID`);

--
-- Indexes for table `tbmembers`
--
ALTER TABLE `tbmembers`
  ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `tbpositions`
--
ALTER TABLE `tbpositions`
  ADD PRIMARY KEY (`position_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mst_question`
--
ALTER TABLE `mst_question`
  MODIFY `que_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `mst_subject`
--
ALTER TABLE `mst_subject`
  MODIFY `sub_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `mst_test`
--
ALTER TABLE `mst_test`
  MODIFY `test_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `mst_user`
--
ALTER TABLE `mst_user`
  MODIFY `user_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `student_table`
--
ALTER TABLE `student_table`
  MODIFY `std_roll_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `subject_table`
--
ALTER TABLE `subject_table`
  MODIFY `subject_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbadministrators`
--
ALTER TABLE `tbadministrators`
  MODIFY `admin_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbcandidates`
--
ALTER TABLE `tbcandidates`
  MODIFY `candidate_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `tbl_attendence`
--
ALTER TABLE `tbl_attendence`
  MODIFY `attID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tbmembers`
--
ALTER TABLE `tbmembers`
  MODIFY `member_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tbpositions`
--
ALTER TABLE `tbpositions`
  MODIFY `position_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
