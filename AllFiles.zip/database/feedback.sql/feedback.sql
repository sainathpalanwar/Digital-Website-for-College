--
-- Database: `feedback`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `user`, `pass`) VALUES
(1, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `message` text NOT NULL,
  `Date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(11) NOT NULL,
  `user_alias` varchar(30) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `programme` varchar(50) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(75) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `date` datetime NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `user_alias`, `Name`, `designation`, `programme`, `semester`, `email`, `password`, `mobile`, `date`, `status`) VALUES
(12, 'Prof1234', 'Prof M.R.Chennoji', 'MTECH', 'BE', 'viii', 'chennoji@gmail.com', '1234', 1234567890, '2018-05-12 09:51:32', 0),
(13, 'Prof9876', 'Prof S.I.Titare', 'MTECH', 'BE', 'viii', 'titare@gmail.com', '1234', 9876543210, '2018-05-12 09:55:08', 0),
(14, 'Prof1234', 'Prof S.A.Jagalpure', 'MTECH', 'BE', 'viii', 'jagalpure@gmail.com', '1234', 1234543211, '2018-05-12 09:56:11', 0),
(15, 'Prof8381', 'Prof Mrs. N.L.Pariyal', 'MTECH', 'BE', 'viii', 'pariyal@gmail.com', '1234', 8381099576, '2018-05-12 09:56:42', 0),
(16, 'Prof8381', 'Prof Mrs. J.S.Kale', 'MTECH', 'BE', 'viii', 'kale@gmail.com', '1234', 8381099576, '2018-05-12 09:57:10', 0),
(17, 'Prof8381', 'Prof Mrs. N.S.Pande', 'MTECH', 'BE', 'viii', 'pande@gmail.com', '1234', 8381099576, '2018-05-12 09:57:35', 0),
(18, 'Prof8381', 'Prof D.S.Naik', 'MTECH', 'BE', 'i', 'naik@gmail.com', '1234', 8381099576, '2018-05-12 09:58:01', 0),
(19, 'Prof8381', 'Prof M.N.Bhandare', 'MTECH', 'BE', 'viii', 'bhandare@gmail.com', '1234', 8381099576, '2018-05-12 09:58:28', 0);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `faculty_id` varchar(50) NOT NULL,
  `How much is the Syllabus coverage` enum('5','4','3','2','1') NOT NULL,
  `Whether the leactures were orginized as per timetable and regula` enum('5','4','3','2','1') NOT NULL,
  `Whether the lectures were well prepared, Organized and course ma` enum('5','4','3','2','1') NOT NULL,
  `Was the Blackboard writing clear and organized` enum('5','4','3','2','1') NOT NULL,
  `Were any Audio-Visual Aids used` enum('5','4','3','2','1') NOT NULL,
  `Whether difficult topics were taught with adequate attention and` enum('5','4','3','2','1') NOT NULL,
  `Was the instructor enthusiastic about teaching` enum('5','4','3','2','1') NOT NULL,
  `Was the instrutor able to deliver lectures with good communicati` enum('5','4','3','2','1') NOT NULL,
  `Were you encouaged to ask questions, to make leactures interacti` enum('5','4','3','2','1') NOT NULL,
  `Did the course improve your understanding of concepts,principles` enum('5','4','3','2','1') NOT NULL,
  `Were the assignments and tests challenging` enum('5','4','3','2','1') NOT NULL,
  `whether the teacher was effective in preparing students for exam` enum('5','4','3','2','1') NOT NULL,
  `What are major suggestion for improvement` text NOT NULL,
  `Why I disliked about this faculty` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `student_id`, `faculty_id`, `How much is the Syllabus coverage`, `Whether the leactures were orginized as per timetable and regula`, `Whether the lectures were well prepared, Organized and course ma`, `Was the Blackboard writing clear and organized`, `Were any Audio-Visual Aids used`, `Whether difficult topics were taught with adequate attention and`, `Was the instructor enthusiastic about teaching`, `Was the instrutor able to deliver lectures with good communicati`, `Were you encouaged to ask questions, to make leactures interacti`, `Did the course improve your understanding of concepts,principles`, `Were the assignments and tests challenging`, `whether the teacher was effective in preparing students for exam`, `What are major suggestion for improvement`, `Why I disliked about this faculty`, `date`) VALUES
(19, 'palanwars@gmail.com', 'chennoji@gmail.com', '3', '3', '2', '1', '1', '1', '3', '2', '1', '1', '2', '2', '\r\ndsfh,kn', '\r\ngfhgfhbgfh', '2018-05-12'),
(20, 'palanwars@gmail.com', 'titare@gmail.com', '4', '4', '4', '4', '4', '4', '4', '4', '4', '4', '4', '4', '\r\nghngnjtrbhf', '\r\nfdgdfgdg', '2018-05-12'),
(21, 'palanwars@gmail.com', 'pariyal@gmail.com', '5', '5', '5', '4', '4', '5', '5', '5', '4', '5', '5', '4', '\r\ngrfgtergtg', '\r\nfgdfgdfg', '2018-05-12'),
(22, 'palanwars@gmail.com', 'bhandare@gmail.com', '4', '4', '5', '5', '5', '5', '4', '5', '5', '4', '3', '4', '\r\nrgrfde', '\r\nregt', '2018-05-12');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `notice_id` int(11) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `Description` text NOT NULL,
  `Date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`notice_id`, `attachment`, `subject`, `Description`, `Date`) VALUES
(8, 'AteekCV_java (1).docx', 'aaaaa', 'dfdfdfd', '2016-07-03 12:39:35');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` char(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pass` varchar(40) NOT NULL,
  `mobile` bigint(11) NOT NULL,
  `programme` varchar(20) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `gender` varchar(40) NOT NULL,
  `image` varchar(50) NOT NULL,
  `dob` date NOT NULL,
  `regid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `pass`, `mobile`, `programme`, `semester`, `gender`, `image`, `dob`, `regid`) VALUES
(16, 'sainath palanwar', 'palanwars@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 8381099576, 'BE', 'viii', 'm', 'download.jpg', '1995-12-29', '2018-05-12 09:33:03'),
(17, 'sumashri landge', 'sumashril100@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 5647653456, 'BE', 'viii', 'f', 'Koala.jpg', '1995-11-07', '2018-05-12 09:59:58'),
(18, 'shrutika mayaskar', 'shrutika@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 9876567890, 'BE', 'viii', 'f', 'Penguins.jpg', '1994-10-15', '2018-05-12 10:01:10'),
(19, 'sarika wathore', 'sarika@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 9878987656, 'BE', 'viii', 'f', 'Tulips.jpg', '1964-08-17', '2018-05-12 10:01:41'),
(20, 'sheetal hendre', 'sheetal@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 5647653456, 'BE', 'i', 'f', 'Hydrangeas.jpg', '1966-09-18', '2018-05-12 10:02:08'),
(21, 'avinash kanjalkar', 'avi@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 8381099576, 'BSC', 'ii', 'm', 'Desert.jpg', '1964-11-08', '2018-05-12 10:02:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`notice_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);
ALTER TABLE `user` ADD FULLTEXT KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `notice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
